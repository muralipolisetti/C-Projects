/* ============================================================
   FILE : ttt.h
   PROJECT : Tic-Tac-Toe vs Computer (C Programming Mini Project)
   PURPOSE : Header file. It contains the common constants, the
             Player structure and the prototypes of every function
             that is defined in ttt.c and used by main.c.
   ============================================================ */

#ifndef TTT_H          /* Include guard: stops this file from being  */
#define TTT_H          /* read twice into the same source file.      */

#include <stdio.h>     /* printf, fopen, fscanf, fprintf, fclose    */
#include <stdlib.h>    /* rand, srand, exit                         */
#include <string.h>    /* strcmp, strcpy, strncpy, strchr           */
#include <time.h>      /* time() is used to seed the random numbers */

/* ------------------------------------------------------------
   BASIC CONSTANTS
   ------------------------------------------------------------ */
#define BOARD_CELLS       9      /* A 3 x 3 board has 9 cells        */
#define MAX_PLAYERS       50     /* Maximum records kept in scores.txt */
#define NAME_LENGTH       32     /* Maximum length of a player name  */

#define SCORES_FILE       "scores.txt"   /* Permanent score file     */
#define TEMP_SCORES_FILE  "scores.tmp"   /* Temporary file for saving*/

#define PLAYER_MARK       'X'    /* The human always plays X         */
#define COMPUTER_MARK     'O'    /* The computer always plays O      */

/* ------------------------------------------------------------
   RESULTS OF A GAME
   getGameResult() returns one of these values.
   ------------------------------------------------------------ */
#define RESULT_ONGOING       0   /* Nobody has won and board is not full */
#define RESULT_PLAYER_WIN    1   /* Human (X) won                        */
#define RESULT_COMPUTER_WIN  2   /* Computer (O) won                     */
#define RESULT_DRAW          3   /* Board full, nobody won               */

/* ------------------------------------------------------------
   OPTIONAL ANSI COLOURS
   Set USE_COLOR to 0 if your terminal does not support colour.
   The game works exactly the same either way.
   ------------------------------------------------------------ */
#define USE_COLOR 1

#if USE_COLOR
  #define CLR_RESET   "\033[0m"
  #define CLR_BOLD    "\033[1m"
  #define CLR_RED     "\033[31m"
  #define CLR_GREEN   "\033[32m"
  #define CLR_YELLOW  "\033[33m"
  #define CLR_CYAN    "\033[36m"
#else
  #define CLR_RESET   ""
  #define CLR_BOLD    ""
  #define CLR_RED     ""
  #define CLR_GREEN   ""
  #define CLR_YELLOW  ""
  #define CLR_CYAN    ""
#endif

/* ------------------------------------------------------------
   STRUCTURE : Player
   One record of the scoreboard / of one line in scores.txt
   ------------------------------------------------------------ */
typedef struct
{
    char name[NAME_LENGTH];  /* Player's name, e.g. "Murali" */
    int  wins;               /* Games won by the player      */
    int  losses;             /* Games won by the computer    */
    int  draws;              /* Games that ended in a draw   */
} Player;

/* ------------------------------------------------------------
   BOARD FUNCTIONS (defined in ttt.c)
   ------------------------------------------------------------ */
void initBoard(char board[]);
void displayBoard(const char board[]);
int  isCellEmpty(const char board[], int index);
int  getPlayerMove(const char board[]);

/* ------------------------------------------------------------
   RULE / RESULT FUNCTIONS (defined in ttt.c)
   ------------------------------------------------------------ */
int  checkWinner(const char board[]);
int  isBoardFull(const char board[]);
int  getGameResult(const char board[]);

/* ------------------------------------------------------------
   COMPUTER OPPONENT FUNCTIONS (defined in ttt.c)
   ------------------------------------------------------------ */
int  findWinningMove(const char board[], char mark);
int  getRandomMove(const char board[]);
int  getComputerMove(const char board[]);

/* ------------------------------------------------------------
   SCOREBOARD / FILE HANDLING FUNCTIONS (defined in ttt.c)
   ------------------------------------------------------------ */
int  loadScores(Player players[], int maxPlayers);
int  saveScores(const Player players[], int count);
int  findPlayer(const Player players[], int count, const char name[]);
void updateScoreboard(Player *player, int result);
void displayScoreboard(const Player *player);

#endif /* TTT_H */
