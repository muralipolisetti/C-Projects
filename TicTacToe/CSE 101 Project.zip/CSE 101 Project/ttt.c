/* ============================================================
   FILE : ttt.c
   PROJECT : Tic-Tac-Toe vs Computer (C Programming Mini Project)
   PURPOSE : Library source file. Every game function lives here.
             main.c only *calls* these functions; it does not
             contain any game logic.
             This file is compiled into the shared library
             libttt.so with : gcc -fPIC -shared -o libttt.so ttt.c
   ============================================================ */

#include "ttt.h"

/* ------------------------------------------------------------
   THE EIGHT WINNING COMBINATIONS
   The board is a 1-dimensional array of 9 cells:

        index :  0 | 1 | 2
                 ---------
                 3 | 4 | 5
                 ---------
                 6 | 7 | 8

   Cell number shown to the user = index + 1, so the classic
   combinations 1,2,3 / 4,5,6 / ... become 0,1,2 / 3,4,5 / ...
   ------------------------------------------------------------ */
static const int WIN_LINES[8][3] =
{
    {0, 1, 2},   /* row 1        (cells 1 2 3) */
    {3, 4, 5},   /* row 2        (cells 4 5 6) */
    {6, 7, 8},   /* row 3        (cells 7 8 9) */
    {0, 3, 6},   /* column 1     (cells 1 4 7) */
    {1, 4, 7},   /* column 2     (cells 2 5 8) */
    {2, 5, 8},   /* column 3     (cells 3 6 9) */
    {0, 4, 8},   /* diagonal     (cells 1 5 9) */
    {2, 4, 6}    /* diagonal     (cells 3 5 7) */
};


/* ============================================================
   1. BOARD FUNCTIONS
   ============================================================ */

/* ------------------------------------------------------------
   initBoard : put the numbers 1..9 into the nine cells.
   An empty cell is a cell that still holds its own number.
   ------------------------------------------------------------ */
void initBoard(char board[])
{
    int i;

    for (i = 0; i < BOARD_CELLS; i++)
    {
        board[i] = (char)('1' + i);   /* '1', '2', ... '9' */
    }
}

/* ------------------------------------------------------------
   displayCell : helper that prints one cell with a colour.
   (static = visible only inside this file)
   ------------------------------------------------------------ */
static void displayCell(char cell)
{
    if (cell == PLAYER_MARK)
    {
        printf("%s%c%s", CLR_CYAN, cell, CLR_RESET);
    }
    else if (cell == COMPUTER_MARK)
    {
        printf("%s%c%s", CLR_RED, cell, CLR_RESET);
    }
    else
    {
        printf("%s%c%s", CLR_YELLOW, cell, CLR_RESET);
    }
}

/* ------------------------------------------------------------
   displayBoard : draw the 3 x 3 board on the screen.
   ------------------------------------------------------------ */
void displayBoard(const char board[])
{
    int row, col;

    printf("\n");
    for (row = 0; row < 3; row++)
    {
        printf("       |       |       \n");

        for (col = 0; col < 3; col++)
        {
            printf("   ");
            displayCell(board[row * 3 + col]);
            printf("   ");
            if (col < 2)
            {
                printf("|");
            }
        }
        printf("\n");

        if (row < 2)
        {
            printf("  _____|_______|_____\n");
        }
    }
    printf("       |       |       \n\n");
}

/* ------------------------------------------------------------
   isCellEmpty : 1 if the cell is still empty, 0 if it is taken.
   A cell is empty when it does not contain X or O.
   ------------------------------------------------------------ */
int isCellEmpty(const char board[], int index)
{
    if (index < 0 || index >= BOARD_CELLS)
    {
        return 0;                        /* safety check */
    }
    return (board[index] != PLAYER_MARK && board[index] != COMPUTER_MARK);
}

/* ------------------------------------------------------------
   getPlayerMove : ask the player for a cell number, validate it
   and return the array index (0..8).  Returns -1 if the input
   stream is closed (Ctrl-D / end of file) so main can exit.
   ------------------------------------------------------------ */
int getPlayerMove(const char board[])
{
    char line[100];      /* the whole line typed by the user */
    int  choice;         /* the number we read from it       */
    char extra;          /* any garbage typed after the number */

    while (1)
    {
        printf("Your move (1-9): ");
        fflush(stdout);

        /* fgets reads a whole line, so bad input can never get
           stuck in the buffer and crash or loop the program. */
        if (fgets(line, sizeof line, stdin) == NULL)
        {
            return -1;               /* end of input -> quit the game */
        }

        /* "5\n"     -> 1 item read,  valid
           "hello"   -> 0 items read,  invalid
           "5x"      -> 2 items read,  invalid (extra character) */
        if (sscanf(line, "%d %c", &choice, &extra) != 1)
        {
            printf("%sInvalid input! Please enter a number from 1 to 9.%s\n\n",
                   CLR_RED, CLR_RESET);
            continue;
        }

        if (choice < 1 || choice > 9)
        {
            printf("%sInvalid input! The number must be between 1 and 9.%s\n\n",
                   CLR_RED, CLR_RESET);
            continue;
        }

        if (!isCellEmpty(board, choice - 1))
        {
            printf("%sCell %d is already occupied! Choose an empty cell.%s\n\n",
                   CLR_RED, choice, CLR_RESET);
            continue;
        }

        return choice - 1;           /* convert 1..9 into 0..8 */
    }
}


/* ============================================================
   2. RULE FUNCTIONS
   ============================================================ */

/* ------------------------------------------------------------
   checkWinner : return PLAYER_MARK ('X') if X has won,
   COMPUTER_MARK ('O') if O has won, or 0 if nobody has won.
   ------------------------------------------------------------ */
int checkWinner(const char board[])
{
    int i;

    for (i = 0; i < 8; i++)
    {
        int a = WIN_LINES[i][0];
        int b = WIN_LINES[i][1];
        int c = WIN_LINES[i][2];

        /* Only X or O can form a line, never a number. */
        if ((board[a] == PLAYER_MARK || board[a] == COMPUTER_MARK) &&
             board[a] == board[b] &&
             board[b] == board[c])
        {
            return board[a];
        }
    }

    return 0;                    /* no winner yet */
}

/* ------------------------------------------------------------
   isBoardFull : 1 when all nine cells contain X or O.
   ------------------------------------------------------------ */
int isBoardFull(const char board[])
{
    int i;

    for (i = 0; i < BOARD_CELLS; i++)
    {
        if (isCellEmpty(board, i))
        {
            return 0;            /* at least one empty cell */
        }
    }
    return 1;
}

/* ------------------------------------------------------------
   getGameResult : one function that tells main.c how the game
   stands right now.  A win is always checked BEFORE a draw, so
   a draw can never be declared when somebody has won.
   ------------------------------------------------------------ */
int getGameResult(const char board[])
{
    int winner = checkWinner(board);

    if (winner == PLAYER_MARK)
    {
        return RESULT_PLAYER_WIN;
    }
    if (winner == COMPUTER_MARK)
    {
        return RESULT_COMPUTER_WIN;
    }
    if (isBoardFull(board))
    {
        return RESULT_DRAW;
    }
    return RESULT_ONGOING;
}


/* ============================================================
   3. COMPUTER OPPONENT FUNCTIONS
      Priority : 1) WIN   2) BLOCK   3) RANDOM
   ============================================================ */

/* ------------------------------------------------------------
   findWinningMove : look for an empty cell that would give
   'mark' three in a row.  Returns the index (0..8) or -1.
   It is used twice:
       findWinningMove(board, COMPUTER_MARK)  -> try to win
       findWinningMove(board, PLAYER_MARK)    -> block the player
   ------------------------------------------------------------ */
int findWinningMove(const char board[], char mark)
{
    char copy[BOARD_CELLS];
    int  i, j;

    for (i = 0; i < BOARD_CELLS; i++)
    {
        /* work on a copy so the real board is never changed */
        for (j = 0; j < BOARD_CELLS; j++)
        {
            copy[j] = board[j];
        }

        if (!isCellEmpty(copy, i))
        {
            continue;                       /* occupied: skip it */
        }

        copy[i] = mark;                     /* try the move      */

        if (checkWinner(copy) == mark)
        {
            return i;                       /* it wins: take it  */
        }
    }

    return -1;                              /* no winning move   */
}

/* ------------------------------------------------------------
   getRandomMove : pick any empty cell at random.
   Returns the index (0..8) or -1 if the board is full.
   ------------------------------------------------------------ */
int getRandomMove(const char board[])
{
    int emptyCells[BOARD_CELLS];   /* stores the indexes of empty cells */
    int count = 0;
    int i;

    for (i = 0; i < BOARD_CELLS; i++)
    {
        if (isCellEmpty(board, i))
        {
            emptyCells[count] = i;
            count++;
        }
    }

    if (count == 0)
    {
        return -1;                 /* no empty cell left */
    }

    /* rand() % count gives a number from 0 to count-1, and we
       map it to one of the empty cells, so the computer can
       NEVER choose a cell that is already occupied. */
    return emptyCells[rand() % count];
}

/* ------------------------------------------------------------
   getComputerMove : the brain of the computer.
   It follows the required priority order exactly.
   ------------------------------------------------------------ */
int getComputerMove(const char board[])
{
    int move;

    /* PRIORITY 1 - WIN : can O win right now? */
    move = findWinningMove(board, COMPUTER_MARK);
    if (move != -1)
    {
        return move;
    }

    /* PRIORITY 2 - BLOCK : can X win on the next move? */
    move = findWinningMove(board, PLAYER_MARK);
    if (move != -1)
    {
        return move;
    }

    /* PRIORITY 3 - RANDOM : nothing urgent, play randomly */
    return getRandomMove(board);
}


/* ============================================================
   4. SCOREBOARD AND FILE HANDLING FUNCTIONS
   ============================================================ */

/* ------------------------------------------------------------
   loadScores : read every record of scores.txt into the array.
   Returns how many records were read (0 if the file is missing
   or empty - that is not an error).
   ------------------------------------------------------------ */
int loadScores(Player players[], int maxPlayers)
{
    FILE *fp;
    int   count = 0;

    fp = fopen(SCORES_FILE, "r");
    if (fp == NULL)
    {
        /* File does not exist yet: the first save will create it. */
        return 0;
    }

    /* %31s  -> at most 31 characters, so the name array
               (NAME_LENGTH = 32) can never overflow.
       The loop also stops at maxPlayers, so the array can
       never overflow either. */
    while (count < maxPlayers &&
           fscanf(fp, "%31s %d %d %d",
                  players[count].name,
                  &players[count].wins,
                  &players[count].losses,
                  &players[count].draws) == 4)
    {
        /* protect against damaged numbers in the file */
        if (players[count].wins   < 0) players[count].wins   = 0;
        if (players[count].losses < 0) players[count].losses = 0;
        if (players[count].draws  < 0) players[count].draws  = 0;

        count++;
    }

    fclose(fp);
    return count;
}

/* ------------------------------------------------------------
   saveScores : write ALL records to a temporary file first and
   then rename it to scores.txt.  If something goes wrong while
   writing, the old scores.txt is still intact.  Because every
   record is written, the other players' scores are preserved.
   Returns 1 on success, 0 on failure.
   ------------------------------------------------------------ */
int saveScores(const Player players[], int count)
{
    FILE *fp;
    int   i;

    fp = fopen(TEMP_SCORES_FILE, "w");
    if (fp == NULL)
    {
        printf("%sWarning: could not open %s for writing.%s\n",
               CLR_RED, TEMP_SCORES_FILE, CLR_RESET);
        return 0;
    }

    for (i = 0; i < count; i++)
    {
        fprintf(fp, "%s %d %d %d\n",
                players[i].name,
                players[i].wins,
                players[i].losses,
                players[i].draws);
    }

    if (fclose(fp) != 0)
    {
        return 0;
    }

    /* replace the old file in one step */
    if (rename(TEMP_SCORES_FILE, SCORES_FILE) != 0)
    {
        remove(TEMP_SCORES_FILE);
        printf("%sWarning: could not update %s.%s\n",
               CLR_RED, SCORES_FILE, CLR_RESET);
        return 0;
    }

    return 1;
}

/* ------------------------------------------------------------
   findPlayer : search the loaded records for a name.
   Returns the index of the record, or -1 if the name is new.
   ------------------------------------------------------------ */
int findPlayer(const Player players[], int count, const char name[])
{
    int i;

    for (i = 0; i < count; i++)
    {
        if (strcmp(players[i].name, name) == 0)   /* equal strings */
        {
            return i;
        }
    }
    return -1;                    /* new player */
}

/* ------------------------------------------------------------
   updateScoreboard : add one game result to the player's record.
   ------------------------------------------------------------ */
void updateScoreboard(Player *player, int result)
{
    if (result == RESULT_PLAYER_WIN)
    {
        player->wins++;
    }
    else if (result == RESULT_COMPUTER_WIN)
    {
        player->losses++;
    }
    else if (result == RESULT_DRAW)
    {
        player->draws++;
    }
}

/* ------------------------------------------------------------
   displayScoreboard : print the scoreboard of one player.
   ------------------------------------------------------------ */
void displayScoreboard(const Player *player)
{
    int total = player->wins + player->losses + player->draws;

    printf("\n%s================================%s\n", CLR_BOLD, CLR_RESET);
    printf("%s           SCOREBOARD           %s\n", CLR_BOLD, CLR_RESET);
    printf("%s================================%s\n\n", CLR_BOLD, CLR_RESET);

    printf("Player Name : %s\n\n", player->name);
    printf("Wins        : %d\n", player->wins);
    printf("Losses      : %d\n", player->losses);
    printf("Draws       : %d\n\n", player->draws);
    printf("Total Games : %d\n\n", total);

    printf("%s================================%s\n\n", CLR_BOLD, CLR_RESET);
}
