/* ============================================================
   FILE : main.c
   PROJECT : Tic-Tac-Toe vs Computer (C Programming Mini Project)
   PURPOSE : Program entry point. This file only controls the
             FLOW of the program: welcome screen, player name,
             loading scores, the turn loop, replay and saving.
             All game logic is inside ttt.c and is reached
             through the prototypes in ttt.h.
   ============================================================ */

#include "ttt.h"

/* ------------------------------------------------------------
   Small helper functions of this file (static = private to main.c)
   ------------------------------------------------------------ */
static void displayWelcome(void);
static void readPlayerName(char name[]);
static int  playGame(Player *player, int playerStarts);
static void announceResult(int result, const char *name);
static int  askPlayAgain(void);


/* ============================================================
   main : the whole game session
   ============================================================ */
int main(void)
{
    Player  players[MAX_PLAYERS];   /* all records of scores.txt   */
    Player  spare;                  /* used if the table is full   */
    Player *current;                /* the record of this player   */
    char    name[NAME_LENGTH];
    int     count;                  /* records loaded from file    */
    int     index;                  /* index of this player        */
    int     playerStarts = 1;       /* 1 = player starts the game  */
    int     keepPlaying;

    /* Seed the random number generator ONCE, with the current
       time, so the computer's random moves keep changing. */
    srand((unsigned)time(NULL));

    displayWelcome();
    readPlayerName(name);

    /* ---------- load the score file ---------- */
    count = loadScores(players, MAX_PLAYERS);
    index = findPlayer(players, count, name);

    if (index >= 0)
    {
        printf("\n%sWelcome back, %s!%s Your previous scores are loaded.\n",
               CLR_GREEN, name, CLR_RESET);
    }
    else if (count < MAX_PLAYERS)
    {
        /* new player : create a record with all scores at zero */
        strcpy(players[count].name, name);
        players[count].wins   = 0;
        players[count].losses = 0;
        players[count].draws  = 0;
        index = count;
        count++;

        printf("\n%sWelcome, %s!%s A new score record was created for you.\n",
               CLR_GREEN, name, CLR_RESET);
    }
    else
    {
        printf("\n%sThe score file already holds %d players.%s\n",
               CLR_YELLOW, MAX_PLAYERS, CLR_RESET);
        printf("You can still play, but this game will not be saved.\n");
        index = -1;
    }

    if (index >= 0)
    {
        current = &players[index];
    }
    else
    {
        strcpy(spare.name, name);
        spare.wins   = 0;
        spare.losses = 0;
        spare.draws  = 0;
        current = &spare;
    }

    printf("\nYou are %c\nComputer is %c\n\nLet's start the game!\n",
           PLAYER_MARK, COMPUTER_MARK);
    printf("========================================\n");

    /* ---------- game loop ---------- */
    do
    {
        keepPlaying = playGame(current, playerStarts);

        if (!keepPlaying)
        {
            break;              /* input stream closed: stop playing */
        }

        /* Alternate who goes first: game 1 player, game 2
           computer, game 3 player, and so on. */
        playerStarts = !playerStarts;

        /* Save after every completed game. */
        if (index >= 0)
        {
            saveScores(players, count);
        }

    } while (askPlayAgain());

    /* ---------- end of the session ---------- */
    displayScoreboard(current);

    if (index >= 0)
    {
        if (saveScores(players, count))
        {
            printf("Scores saved to %s\n\n", SCORES_FILE);
        }
    }

    printf("%sThanks for playing, %s. Goodbye!%s\n\n",
           CLR_GREEN, current->name, CLR_RESET);

    return 0;
}


/* ============================================================
   displayWelcome : the title screen
   ============================================================ */
static void displayWelcome(void)
{
    printf("\n%s", CLR_BOLD);
    printf("========================================\n");
    printf("              TIC-TAC-TOE               \n");
    printf("            PLAYER VS COMPUTER          \n");
    printf("========================================%s\n\n", CLR_RESET);
}


/* ============================================================
   readPlayerName : ask the name until something valid is typed
   ============================================================ */
static void readPlayerName(char name[])
{
    char line[100];

    while (1)
    {
        printf("Enter your name: ");
        fflush(stdout);

        if (fgets(line, sizeof line, stdin) == NULL)
        {
            strcpy(name, "Player");     /* no input at all */
            return;
        }

        /* remove the newline (and any carriage return) at the end */
        line[strcspn(line, "\r\n")] = '\0';

        if (line[0] == '\0')
        {
            printf("%sThe name cannot be empty. Please try again.%s\n\n",
                   CLR_RED, CLR_RESET);
            continue;
        }

        if (strchr(line, ' ') != NULL)
        {
            printf("%sPlease use a single word without spaces.%s\n\n",
                   CLR_RED, CLR_RESET);
            continue;
        }

        /* copy the name safely into the fixed size array.
           %31s stops at 31 characters, so a 32 byte array
           can never overflow. */
        if (sscanf(line, "%31s", name) != 1)
        {
            printf("%sThe name cannot be empty. Please try again.%s\n\n",
                   CLR_RED, CLR_RESET);
            continue;
        }
        return;
    }
}


/* ============================================================
   playGame : play ONE complete game
   Returns 1 when the game finished normally, 0 when the input
   stream was closed (so main can save the scores and exit).
   ============================================================ */
static int playGame(Player *player, int playerStarts)
{
    char board[BOARD_CELLS];
    int  result      = RESULT_ONGOING;
    int  playerTurn  = playerStarts;    /* 1 = human, 0 = computer */
    int  move;

    initBoard(board);

    printf("\n%s========================================%s\n",
           CLR_BOLD, CLR_RESET);
    printf("   %s vs COMPUTER\n", player->name);
    printf("   First turn : %s\n",
           playerStarts ? player->name : "Computer");
    printf("%s========================================%s\n",
           CLR_BOLD, CLR_RESET);

    displayBoard(board);

    /* ---------- the turn loop ---------- */
    while (result == RESULT_ONGOING)
    {
        if (playerTurn)
        {
            printf("%s--- YOUR TURN (%s = %c) ---%s\n",
                   CLR_CYAN, player->name, PLAYER_MARK, CLR_RESET);

            move = getPlayerMove(board);
            if (move == -1)
            {
                printf("\nInput closed. Ending the game.\n");
                return 0;               /* stop the session */
            }

            board[move] = PLAYER_MARK;
            printf("%s%s plays cell %d.%s\n", CLR_CYAN, player->name,
                   move + 1, CLR_RESET);
        }
        else
        {
            printf("%s--- COMPUTER'S TURN (%c) ---%s\n",
                   CLR_RED, COMPUTER_MARK, CLR_RESET);

            move = getComputerMove(board);
            if (move == -1)
            {
                break;                  /* board full: cannot happen  */
            }

            board[move] = COMPUTER_MARK;
            printf("Computer plays cell %d.\n", move + 1);
        }

        displayBoard(board);

        /* check the result after EVERY move */
        result = getGameResult(board);

        playerTurn = !playerTurn;       /* switch turns */
    }

    announceResult(result, player->name);

    /* update and show the scoreboard */
    updateScoreboard(player, result);
    displayScoreboard(player);

    return 1;
}


/* ============================================================
   announceResult : say who won / draw
   ============================================================ */
static void announceResult(int result, const char *name)
{
    if (result == RESULT_PLAYER_WIN)
    {
        printf("\n%s****************************************%s\n",
               CLR_GREEN, CLR_RESET);
        printf("%s        Congratulations! You won!        %s\n",
               CLR_GREEN, CLR_RESET);
        printf("%s****************************************%s\n",
               CLR_GREEN, CLR_RESET);
    }
    else if (result == RESULT_COMPUTER_WIN)
    {
        printf("\n%s****************************************%s\n",
               CLR_RED, CLR_RESET);
        printf("%s   Computer wins! Better luck next time. %s\n",
               CLR_RED, CLR_RESET);
        printf("%s****************************************%s\n",
               CLR_RED, CLR_RESET);
    }
    else
    {
        printf("\n%s****************************************%s\n",
               CLR_YELLOW, CLR_RESET);
        printf("%s          The game is a draw!           %s\n",
               CLR_YELLOW, CLR_RESET);
        printf("%s****************************************%s\n",
               CLR_YELLOW, CLR_RESET);
    }

    printf("Well played, %s.\n", name);
}


/* ============================================================
   askPlayAgain : Y/y = yes, N/n = no, anything else = ask again
   ============================================================ */
static int askPlayAgain(void)
{
    char line[100];

    while (1)
    {
        printf("Do you want to play again? (Y/N): ");
        fflush(stdout);

        if (fgets(line, sizeof line, stdin) == NULL)
        {
            printf("\n");
            return 0;                   /* end of input: stop */
        }

        if (line[0] == 'Y' || line[0] == 'y')
        {
            return 1;
        }
        if (line[0] == 'N' || line[0] == 'n')
        {
            return 0;
        }

        printf("%sPlease answer Y for yes or N for no.%s\n", CLR_RED, CLR_RESET);
    }
}
